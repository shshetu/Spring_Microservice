package com.shetu.spring_microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
